SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[events](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[name] [nvarchar](50) NOT NULL,
	[vip] [int] NULL,
	[regular] [int] NULL,
	[early_bird] [int] NULL,
	[vip_price] [int] NOT NULL,
	[r_price] [int] NOT NULL,
	[eb_price] [int] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[events] ADD  CONSTRAINT [PK_events] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE [dbo].[events] ADD  CONSTRAINT [DEFAULT_events_vip]  DEFAULT ((0)) FOR [vip]
GO
ALTER TABLE [dbo].[events] ADD  CONSTRAINT [DEFAULT_events_regular]  DEFAULT ((0)) FOR [regular]
GO
ALTER TABLE [dbo].[events] ADD  CONSTRAINT [DEFAULT_events_early_bird]  DEFAULT ((0)) FOR [early_bird]
GO
